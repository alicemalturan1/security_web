
<div class="vertical-menu">

    <div class="h-100">



        <!--- Sidemenu -->
        <div id="sidebar-menu">
            <!-- Left Menu Start -->
            <ul class="metismenu list-unstyled" id="side-menu">


                <li>
                    <a href="/community" class="waves-effect">
                        <i class="mdi mdi-account-supervisor"></i>
                        <span>Topluluk</span>
                    </a>

                </li>
                <li>
                    <a href="/chat" class="waves-effect">
                        <i class="bx bxs-message-square-dots"></i>
                        <span>Chat</span>
                    </a>

                </li>
                <li>
                    <a href="/users" class="waves-effect">
                        <i class="bx bx-id-card"></i>
                        <span>Üyeler</span>
                    </a>

                </li>




            </ul>
        </div>
        <!-- Sidebar -->
    </div>
</div>
<!-- Left Sidebar End -->
<?php /**PATH C:\Users\Ali\security_web\resources\views/left_menu.blade.php ENDPATH**/ ?>