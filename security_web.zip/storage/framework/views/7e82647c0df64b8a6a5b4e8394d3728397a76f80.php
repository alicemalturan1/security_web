<?php $color=''; ?>
<?php if(Illuminate\Support\Facades\Cookie::get('panel_color')): ?>
    <?php if(Illuminate\Support\Facades\Cookie::get('panel_color')=="dark"): ?>
        <?php
            $color='-dark';
        ?>
    <?php else: ?>
        <?php
            $color='';
        ?>
    <?php endif; ?>
<?php endif; ?>
<link href="/admin-assets/assets/css/bootstrap<?php echo e($color); ?>.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
<!-- App Css-->
<link href="/admin-assets/assets/css/app<?php echo e($color); ?>.min.css" id="app-style" rel="stylesheet" type="text/css" />
<?php /**PATH C:\Users\Ali\security_web\resources\views/panelstyle.blade.php ENDPATH**/ ?>